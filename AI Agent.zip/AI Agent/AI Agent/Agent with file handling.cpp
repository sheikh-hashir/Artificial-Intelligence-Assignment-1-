#include<iostream>
#include<stack>
#include<queue>
#include<string>
#include<fstream>
using namespace std;
struct Node {
	Node * parent;
	int state;
	int action;
	int cost;
};
void findPath(string path, string& start, string& end)
{
	int i = 0;
	while (path[i] != '	')
	{
		start += path[i];
		i++;
	}
	int j = 0;
	i++;
	while (path[i] != '\0')
	{
		end += path[i]; i++;
	}
}
void findIndex(string states[], string start, string end, int& sIndex, int& eIndex)
{
	for (int i = 0; i < 8; i++)
	{
		if (states[i] == start)
			sIndex = i;
		if (states[i] == end)
			eIndex = i;
	}
}
bool isGoal(Node *algo, int goal)
{
	if (algo->state == goal)
	{
		return true;
	}
	return false;
}
int main()
{
	fstream file("Input.txt", ios::in);
	int N, M, T;
	if (file.peek() >= 0) { file >> N; }
	if (file.peek() >= 0) { file >> M; }
	if (file.peek() >= 0) { file >> T; }
	file.ignore(); file.ignore();
	string *states = new string[N];
	for (int i = 0; i < N; i++)
	{
		getline(file, states[i]);
	}
	file.ignore();
	string *action = new string[M];// = { "Clean","MoveToRoom1","MoveToRoom2" };
	for (int i = 0; i < M; i++)
	{
		getline(file, action[i]);
	}
	file.ignore();
	int **input = new int*[N];
	for (int i = 0; i < N; i++)
	{
		input[i] = new int[M];
	}
	for (int i = 0; i < N; i++)
	{
		for (int j = 0; j < M; j++)
		{
			if (file.peek() >= 0) {
				file >> input[i][j];
			}
		}
	}
	file.ignore();	file.ignore();
	for (int i = 0; i < T; i++)
	{
		bool *isChecked = new bool[N];
		for (int i = 0; i < N; i++)
		{
			isChecked[i] = 0;
		}
		string path;
		string start = "", end = "";
		getline(file, path);
		findPath(path, start, end);
		int sIndex, eIndex;
		findIndex(states, start, end, sIndex, eIndex);
		Node *algo = new Node;
		queue<Node*> frontier;
		algo->state = sIndex;
		algo->action = -1;
		algo->parent = NULL;
		algo->cost = 0;
		frontier.push(algo);
		isChecked[algo->state] = 1;
		Node *child = NULL;
		int l = 0;
		bool break_loop = false;
		bool parent_is_goal = false;
		bool no_solution = false;
		while (!frontier.empty())
		{
			algo = frontier.front();
			frontier.pop();
			bool goal = isGoal(algo, eIndex);
			if (goal)
			{
				parent_is_goal = true;
				break;
			}
			else
			{
				for (int i = 0; i < M; i++)
				{
					if (isChecked[input[algo->state][i]] == 0)
					{
						child = new Node;
						int index = input[algo->state][i];
						isChecked[index] = 1;
						child->parent = algo;
						child->state = input[algo->state][i];
						child->action = i;
						child->cost = child->parent->cost + 1;
						bool goal = isGoal(child, eIndex);
						if (goal)
						{
							break_loop = true;
							break;
						}
						frontier.push(child);
					}
				}
			}
			if (break_loop)
			{
				break;
			}
			if (frontier.empty())
			{
				no_solution = true;
			}
		}
		if ((!parent_is_goal) && no_solution == false)
		{
			stack<int> store;
			while (child != NULL)
			{
				store.push(child->action);
				child = child->parent;
			}
			store.pop();
			string final;
			while (!store.empty())
			{
				final += action[store.top()];
				final += "->";
				store.pop();
			}
			final = final.substr(0, final.length() - 2);
			cout << final << endl;
		}
		else if ((no_solution == true) && (parent_is_goal == false))
		{
			cout << "No path exist\n";
		}
		else {
			cout << "parent is goal\n";
		}
	}
}